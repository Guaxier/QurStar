<?php
// 本php为中心数据配置文件，用于配置各种常量


// 数据库连接配置
define('DB_HOST', 'localhost');
define('DB_USER', 'videosql');
define('DB_PASS', 'videosql');
define('DB_NAME', 'videosql');




?>








//smspend.php
