<?php
// 使用 include 导入 HTML 文件
include 'index.html';

// 或者使用 require 导入 HTML 文件
// require 'example.html';